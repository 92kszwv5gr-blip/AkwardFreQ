AkwardFreQ — Windows release build
====================================

What's in this zip
-------------------
    AkwardFreQ.vst3/     The actual VST3 plugin — install this in Ableton.
    Standalone/          A standalone .exe — same plugin, runs as its own
                          app, no DAW needed. Useful for a quick test before
                          setting up Ableton, or on a machine without it.

Both contain a copy of onnxruntime.dll (needed for AI stem separation) and
are self-contained — no other mingw/MSVC runtime DLLs are required, since
this was built with a static-linked runtime.

Installing the VST3 in Ableton
-------------------------------
1. Copy the whole "AkwardFreQ.vst3" folder into:
       %COMMONPROGRAMFILES%\VST3
   (typically C:\Program Files\Common Files\VST3)
2. Get the AI model — not included here, ~300MB, one command (see the main
   repo README's "Quick Start" section for the exact commands). Without it,
   the plugin still loads and works; only AI stem separation is unavailable
   until the model is added.
3. Copy the resulting Models\htdemucs.onnx into:
       ...\VST3\AkwardFreQ.vst3\Contents\x86_64-win\
   next to onnxruntime.dll and the plugin binary.
4. In Ableton: Preferences -> Plug-ins -> Rescan. AkwardFreQ appears under
   VST3.

Using the Standalone .exe instead
-----------------------------------
Just run AkwardFreQ.exe directly (same folder as onnxruntime.dll). Drop
htdemucs.onnx into a "Models" folder next to the .exe if you want AI
separation there too.

How this was built
-------------------
Cross-compiled from Linux via mingw-w64 (see the main repo's
toolchain-mingw64.cmake and its README section "Tried it — does it
actually work?" for the full story, including the fixes that were needed
to get ONNX Runtime's headers and a static runtime working under mingw).
This is a real, genuinely cross-compiled Windows binary — verified as a
PE32+ executable, not a stub or a mockup — but it has not been tested by
its authors inside an actual copy of Ableton on a real Windows machine.
File an issue if something doesn't load or behave as expected.
